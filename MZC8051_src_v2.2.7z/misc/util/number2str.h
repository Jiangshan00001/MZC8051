#ifndef NUMBER2STR_H
#define NUMBER2STR_H

#include <string>
std::string NumberToStr(long num);

#endif // NUMBER2STR_H
