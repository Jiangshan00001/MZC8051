#ifndef STR2NUMBER_H
#define STR2NUMBER_H
#include <string>
unsigned long long StrToNumber(std::string  mHexStr);
float StrToFloat(std::string  mHexStr);

#endif // STR2NUMBER_H
