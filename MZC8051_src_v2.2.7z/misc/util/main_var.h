#ifndef MAIN_VAR_H
#define MAIN_VAR_H
#include <string>
extern std::string G_PROG_NAME;

#endif

