#ifndef TRIM_H
#define TRIM_H

#include<string>

std::string& trim(std::string &s);
std::string& trim1(std::string &s, char tr_char=' ');

#endif // TRIM_H
