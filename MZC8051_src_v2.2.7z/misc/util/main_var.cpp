#include <string>
std::string G_PROG_NAME;
