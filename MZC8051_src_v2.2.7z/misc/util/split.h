#ifndef SPLIT_H
#define SPLIT_H

#include<vector>
#include<string>

std::vector<std::string>  split(std::string str, std::string token, bool remove_empty=0);

#endif // SPLIT_H
