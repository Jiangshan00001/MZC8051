#ifndef C51_FILTER_MANAGE_H
#define C51_FILTER_MANAGE_H

#include "icodes.h"

class c51_filter_manage
{
public:
    c51_filter_manage();

    void do_filter(icodes* ics);


};

#endif // C51_FILTER_MANAGE_H
