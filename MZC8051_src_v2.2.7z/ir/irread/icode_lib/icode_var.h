#ifndef ICODE_VAR_H
#define ICODE_VAR_H

#include "icode_base.h"


#endif // ICODE_VAR_H
