#include "icode.h"
#include "icode_io.h"

icode_io::icode_io()
{
}

std::string icode_io::icode_to_str(icode *ic)
{




}

icode *icode_io::str_to_icode(std::string icode_str)
{

}

int icode_io::save_icode(icode *ic, std::string file_name)
{

}

icode *icode_io::read_icode(std::string file_name)
{

}

int icode_io::save_icode_vec(std::vector<icode *> ic, std::string file_name)
{

}

std::vector<icode *> icode_io::read_icode_vec(std::string file_name)
{

}
