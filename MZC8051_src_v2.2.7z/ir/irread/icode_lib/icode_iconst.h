#ifndef ICODE_ICONST_H
#define ICODE_ICONST_H

#include "icode_base.h"
#include "icode_var.h"


#endif // ICODE_ICONST_H
