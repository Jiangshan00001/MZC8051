#ifndef ICODE_STRING_H
#define ICODE_STRING_H

#include "icode_base.h"

///
/// \brief The icode_string class
/// 字符串标识的类
/// 实际使用：m_icode_number m_type name


#endif // ICODE_STRING_H
