#include "ast_base.h"

ast_base::ast_base()
{
}
