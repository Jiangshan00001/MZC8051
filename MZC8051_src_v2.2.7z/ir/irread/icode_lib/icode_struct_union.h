#ifndef ICODE_STRUCT_UNION_H
#define ICODE_STRUCT_UNION_H

#include <vector>
#include <string>
#include "icode_base.h"
#include "icode_var.h"



#endif // ICODE_STRUCT_UNION_H
