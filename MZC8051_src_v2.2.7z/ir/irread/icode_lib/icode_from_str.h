#ifndef ICODE_FROM_STR_H
#define ICODE_FROM_STR_H

#include "icode.h"

#endif