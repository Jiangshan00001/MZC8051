#ifndef ICODE_LABEL_H
#define ICODE_LABEL_H

#include "icode_base.h"


#endif // ICODE_LABEL_H
