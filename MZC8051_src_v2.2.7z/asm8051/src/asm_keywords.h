#ifndef ASM_KEYWORDS_H
#define ASM_KEYWORDS_H

#include <vector>
#include <string>


int asm8051_context_init(void *mCtx);

#endif // ASM_KEYWORDS_H
