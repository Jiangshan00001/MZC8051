#ifndef ASM_TEST_CODE_GEN_H
#define ASM_TEST_CODE_GEN_H

#include <string>

class asm_test_code_gen
{
public:
    asm_test_code_gen();
    std::string test_code_gen1();
};

#endif // ASM_TEST_CODE_GEN_H
